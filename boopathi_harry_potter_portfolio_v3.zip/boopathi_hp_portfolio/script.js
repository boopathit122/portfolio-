const nav=document.querySelector('.nav'),menu=document.querySelector('.menu');
if(menu)menu.addEventListener('click',()=>nav.classList.toggle('mobile-open'));
const W='<svg viewBox="0 0 46 46"><path d="M4 42L34 12" stroke="#5b3a1d" stroke-width="4" stroke-linecap="round"/><path d="M30 16l4-4" stroke="#d4a93c" stroke-width="5" stroke-linecap="round"/><text x="34" y="14" fill="#fff6c8" font-size="14">✦</text></svg>';
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
function spark(x,y,n){if(reduce)return;for(let i=0;i<n;i++){const s=document.createElement('span');s.className='spark';s.textContent=Math.random()>.5?'✦':'✧';s.style.left=x+'px';s.style.top=y+'px';s.style.setProperty('--dx',(Math.random()*60-30)+'px');s.style.setProperty('--dy',(Math.random()*60-10)+'px');document.body.appendChild(s);setTimeout(()=>s.remove(),800)}}
if(matchMedia('(pointer:fine)').matches){const w=document.createElement('div');w.className='wand';w.innerHTML=W;document.body.appendChild(w);
addEventListener('mousemove',e=>{w.style.left=e.clientX+'px';w.style.top=e.clientY+'px';spark(e.clientX+30,e.clientY-30,1)});
addEventListener('click',e=>spark(e.clientX+30,e.clientY-30,14))}
const f=document.querySelector('.owl-form');
if(f)f.addEventListener('submit',async e=>{e.preventDefault();const st=f.querySelector('.status'),o=document.querySelector('.owl.fly');st.textContent='Tying the letter to the owl…';
try{const r=await fetch(f.action,{method:'POST',body:new FormData(f),headers:{Accept:'application/json'}});
if(r.ok){o.classList.remove('go');void o.offsetWidth;o.classList.add('go');st.textContent='Your owl is on its way. I will reply soon.';f.reset()}else throw 0}
catch(_){st.textContent='The owl could not leave. Please try again or email me directly.'}});
